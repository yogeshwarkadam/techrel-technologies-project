import { AwsComponent } from './aws/aws.component';
import { TestingComponent } from './testing/testing.component';
import { JawaComponent } from './jawa/jawa.component';
import { AngularComponent } from './angular/angular.component';
import { CoursesComponent } from './courses/courses.component';
import { ClientsComponent } from './clients/clients.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path:'home',component:HomeComponent},
  { path:'about',component:AboutComponent},
  { path:'testimonials',component:TestimonialsComponent},
  { path:'clients',component:ClientsComponent},
  { path:'angular',component:AngularComponent},
  { path:'testing',component:TestingComponent},
  { path:'jawa',component:JawaComponent},
  { path:'aws',component:AwsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
