import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jawa',
  templateUrl: './jawa.component.html',
  styleUrls: ['./jawa.component.css']
})
export class JawaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
