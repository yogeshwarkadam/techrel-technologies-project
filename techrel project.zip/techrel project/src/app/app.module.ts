import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ClientsComponent } from './clients/clients.component';
import { CoursesComponent } from './courses/courses.component';
import { AngularComponent } from './angular/angular.component';
import { JawaComponent } from './jawa/jawa.component';
import { TestingComponent } from './testing/testing.component';
import { AwsComponent } from './aws/aws.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    FooterComponent,
    HomeComponent,
    AboutComponent,
    TestimonialsComponent,
    ClientsComponent,
    CoursesComponent,
    AngularComponent,
    JawaComponent,
    TestingComponent,
    AwsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
